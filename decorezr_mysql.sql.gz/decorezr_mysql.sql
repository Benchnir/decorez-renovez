-- MySQL dump 10.13  Distrib 5.1.70, for unknown-linux-gnu (x86_64)
--
-- Host: localhost    Database: decorezr_mysql
-- ------------------------------------------------------
-- Server version	5.1.70-cll

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `announcement`
--

DROP TABLE IF EXISTS `announcement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `department_id` int(11) DEFAULT NULL,
  `description` varchar(1000) NOT NULL,
  `is_visible` tinyint(1) NOT NULL,
  `urgent_expire_at` datetime DEFAULT NULL,
  `top_list_expire_at` datetime DEFAULT NULL,
  `budget` int(11) NOT NULL,
  `duration` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  `is_image` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_4DB9D91C7597D3FE` (`member_id`),
  KEY `IDX_4DB9D91CAE80F5DF` (`department_id`),
  CONSTRAINT `FK_4DB9D91C7597D3FE` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`),
  CONSTRAINT `FK_4DB9D91CAE80F5DF` FOREIGN KEY (`department_id`) REFERENCES `department` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcement`
--

LOCK TABLES `announcement` WRITE;
/*!40000 ALTER TABLE `announcement` DISABLE KEYS */;
INSERT INTO `announcement` (`id`, `member_id`, `department_id`, `description`, `is_visible`, `urgent_expire_at`, `top_list_expire_at`, `budget`, `duration`, `created_at`, `updated_at`, `is_image`) VALUES (4,4,45,'j\'ai besoin d\'aie pour ma salle de bain',1,NULL,NULL,1,2,'2013-04-12 21:32:26','2013-04-12 21:32:26',0),(5,4,45,'j\'ai besoin d\'aie pour ma salle de bain2',1,NULL,NULL,1,2,'2013-04-12 21:32:26','2013-04-12 21:32:26',0),(6,4,45,'j\'ai besoin d\'aie pour ma salle de bain3',1,NULL,NULL,1,2,'2013-04-12 21:32:26','2013-04-12 21:32:26',0),(7,4,45,'j\'ai besoin d\'aie pour ma salle de bain4',1,NULL,'2013-04-30 00:00:00',1,2,'2013-04-12 21:32:26','2013-04-12 21:32:26',0),(8,4,45,'j\'ai besoin d\'aie pour ma salle de bain5',1,NULL,'2013-04-30 00:00:00',1,2,'2013-04-12 21:32:26','2013-04-12 21:32:26',0),(9,4,45,'j\'ai besoin d\'aie pour ma salle de bain6',1,NULL,'2013-04-30 00:00:00',1,2,'2013-04-12 21:32:26','2013-04-12 21:32:26',0),(10,4,45,'j\'ai besoin d\'aie pour ma salle de bain7',1,NULL,NULL,1,2,'2013-04-12 21:32:26','2013-04-12 21:32:26',0),(11,4,45,'j\'ai besoin d\'aie pour ma salle de bain8',1,'2013-04-30 00:00:00',NULL,1,2,'2013-04-12 21:32:26','2013-04-12 21:32:26',0),(12,4,45,'j\'ai besoin d\'aie pour ma salle de bain9',1,NULL,NULL,1,2,'2013-04-12 21:32:26','2013-04-12 21:32:26',0),(13,4,45,'j\'ai besoin d\'aie pour ma salle de bain10',1,NULL,NULL,1,2,'2013-04-12 21:32:26','2013-04-12 21:32:26',0),(14,4,45,'j\'ai besoin d\'aie pour ma salle de bain11',1,NULL,NULL,1,2,'2013-04-12 21:32:26','2013-04-12 21:32:26',0),(15,4,45,'j\'ai besoin d\'aie pour ma salle de bain12',1,NULL,NULL,1,2,'2013-04-12 21:32:26','2013-04-12 21:32:26',0),(16,4,45,'j\'ai besoin d\'aie pour ma salle de bain13',1,NULL,NULL,1,2,'2013-04-12 21:32:26','2013-04-12 21:32:26',0),(17,4,45,'j\'ai besoin d\'aie pour ma salle de bain14',1,NULL,NULL,1,2,'2013-04-12 21:32:26','2013-04-12 21:32:26',0),(18,21,7,'test',1,'2013-05-07 14:15:47','2013-04-30 14:19:40',1,1,'2013-04-14 02:52:55','2013-04-14 13:59:36',1),(21,21,35,'aefaofn eif fze ffzefzefze',1,NULL,NULL,1,1,'2013-04-28 00:34:18','2013-04-28 00:34:18',0),(22,26,69,'Refaire un sdb de 6m2',1,NULL,NULL,2,2,'2013-05-01 01:42:28','2013-05-01 01:42:28',0),(23,30,101,'j\\\'ai besoin d\\\'aide pour refaire ma maison',1,NULL,NULL,4,4,'2013-05-03 19:26:27','2013-05-03 19:26:27',0),(24,24,94,' Une maison pleine de trucs à réparer Une maison pleine de trucs à réparer\r\nUne maison pleine de trucs à réparer Une maison pleine de trucs à réparer\r\nUne maison pleine de trucs à réparer',1,NULL,NULL,3,1,'2013-05-07 18:38:05','2013-05-07 18:38:05',0),(25,33,94,'J\\\'ai une cuisine à refaire et quelques travaux, parquet et ainsi de suite',1,NULL,NULL,3,3,'2013-05-08 22:24:24','2013-05-08 22:24:24',0),(26,35,91,'Je cherche un artisan pour refaire ma salle de bain. Faillance, enduit, etc fourni par mes soins.',1,NULL,NULL,1,1,'2013-05-24 16:45:23','2013-05-24 16:45:23',0);
/*!40000 ALTER TABLE `announcement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `announcement_job`
--

DROP TABLE IF EXISTS `announcement_job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `announcement_job` (
  `job_id` int(11) NOT NULL,
  `announcement_id` int(11) NOT NULL,
  PRIMARY KEY (`job_id`,`announcement_id`),
  KEY `IDX_134E3746BE04EA9` (`job_id`),
  KEY `IDX_134E3746913AEA17` (`announcement_id`),
  CONSTRAINT `FK_134E3746913AEA17` FOREIGN KEY (`announcement_id`) REFERENCES `job` (`id`),
  CONSTRAINT `FK_134E3746BE04EA9` FOREIGN KEY (`job_id`) REFERENCES `announcement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `announcement_job`
--

LOCK TABLES `announcement_job` WRITE;
/*!40000 ALTER TABLE `announcement_job` DISABLE KEYS */;
INSERT INTO `announcement_job` (`job_id`, `announcement_id`) VALUES (4,1),(4,2),(18,3),(21,8),(21,12),(21,24),(22,1),(22,15),(23,2),(23,34),(24,12),(25,1),(25,2),(25,3),(25,8),(25,14),(26,1),(26,6),(26,8);
/*!40000 ALTER TABLE `announcement_job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `avatar`
--

DROP TABLE IF EXISTS `avatar`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `avatar` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `path` varchar(255) NOT NULL,
  `is_main` tinyint(1) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_1677722F7597D3FE` (`member_id`),
  CONSTRAINT `FK_1677722F7597D3FE` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `avatar`
--

LOCK TABLES `avatar` WRITE;
/*!40000 ALTER TABLE `avatar` DISABLE KEYS */;
INSERT INTO `avatar` (`id`, `member_id`, `path`, `is_main`) VALUES (10,18,'8ba2390b8828e29f0e4397bd793234cb1358005580_HTML_Color_Black.png',1),(11,18,'cc9d6b87ab2b16760b10047be44205c01358006715_js.png',0),(12,18,'1ae1e1f46b3cc85cdf2a8bbdb7a20befnodejs.png',0),(13,21,'6a6f96ead9f16f66e664db303609eb5becology_D.jpg',1),(14,30,'5098095f9b717475b6566936625c00ed1358005580_HTML_Color_Black.png',1),(17,23,'a26ce221c4082b090895ae94feb76777test.png',0),(18,24,'130d0d23e57e1cbacf59104e920627b8id.png',1),(19,33,'36891076cbdf895059ff52777266e062id.png',1),(21,7,'4f8bef2c44b4222d0ea8b36c6e961fadtest.jpg',0),(23,35,'c4cb4ed64b7ea7bca0433c2ce1dc6539respcond01_blndhorseb.jpg',1),(25,23,'9280636ad326deda358ff61b71c08ecfrespcond01_blndhorseb.jpg',0);
/*!40000 ALTER TABLE `avatar` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `comment`
--

DROP TABLE IF EXISTS `comment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `comment` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `service_id` int(11) DEFAULT NULL,
  `type` int(11) NOT NULL,
  `message` longtext NOT NULL,
  `status` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_9474526C7597D3FE` (`member_id`),
  KEY `IDX_9474526CED5CA9E6` (`service_id`),
  CONSTRAINT `FK_9474526C7597D3FE` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`),
  CONSTRAINT `FK_9474526CED5CA9E6` FOREIGN KEY (`service_id`) REFERENCES `service` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `comment`
--

LOCK TABLES `comment` WRITE;
/*!40000 ALTER TABLE `comment` DISABLE KEYS */;
INSERT INTO `comment` (`id`, `member_id`, `service_id`, `type`, `message`, `status`, `created_at`, `updated_at`) VALUES (1,18,13,0,'test',0,'2013-04-18 17:05:29','2013-04-18 17:05:29'),(2,18,5,0,'test',0,'2013-04-18 22:25:57','2013-04-18 22:25:57'),(3,23,7,1,'Très bon prestataire',0,'2013-04-26 09:20:12','2013-04-26 09:20:12'),(4,23,13,0,'top',0,'2013-04-28 15:40:04','2013-04-28 15:40:04'),(5,8,6,0,'test',0,'2013-04-29 02:01:34','2013-04-29 02:01:34'),(6,8,6,0,'test',0,'2013-04-29 02:05:13','2013-04-29 02:05:13'),(7,8,6,0,'test',0,'2013-04-29 02:06:06','2013-04-29 02:06:06'),(8,8,6,0,'test',0,'2013-04-29 02:08:30','2013-04-29 02:08:30'),(9,26,14,1,'test commentaire positif',0,'2013-05-01 17:39:51','2013-05-01 17:39:51'),(10,33,13,0,' Pas top comme artsan Pas top comme artsan Pas top comme artsan Pas top comme artsan\r\nPas top comme artsan Pas top comme artsan Pas top comme artsan Pas top comme artsan vPas top comme artsan\r\nPas top comme artsanPas top comme artsan',0,'2013-05-08 22:29:41','2013-05-08 22:29:41'),(11,23,16,0,'très bien',0,'2013-05-11 00:59:50','2013-05-11 00:59:50'),(12,23,13,-1,'test',0,'2013-05-17 00:27:20','2013-05-17 00:27:20'),(13,23,16,0,'test',0,'2013-05-20 18:58:37','2013-05-20 18:58:37'),(14,21,2,1,'très bon !!',0,'2013-05-22 01:36:01','2013-05-22 01:36:01'),(15,23,16,0,'test',0,'2013-05-24 01:01:43','2013-05-24 01:01:43');
/*!40000 ALTER TABLE `comment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `department`
--

DROP TABLE IF EXISTS `department`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `department` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `region_id` int(11) DEFAULT NULL,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_CD1DE18A98260155` (`region_id`),
  CONSTRAINT `FK_CD1DE18A98260155` FOREIGN KEY (`region_id`) REFERENCES `region` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=103 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `department`
--

LOCK TABLES `department` WRITE;
/*!40000 ALTER TABLE `department` DISABLE KEYS */;
INSERT INTO `department` (`id`, `region_id`, `name`) VALUES (1,23,'Ain'),(2,21,'Aisne'),(3,4,'Allier'),(4,19,'Alpes de haute provence'),(5,19,'Hautes alpes'),(6,19,'Alpes maritimes'),(7,23,'Ardèche'),(8,9,'Ardennes'),(9,17,'Ariège'),(10,9,'Aube'),(11,14,'Aude'),(12,17,'Aveyron'),(13,19,'Bouches du rhône'),(14,5,'Calvados'),(15,4,'Cantal'),(16,22,'Charente'),(17,22,'Charente maritime'),(18,8,'Cher'),(19,15,'Corrèze'),(21,6,'Côte d\'or'),(22,7,'Côtes d\'Armor'),(23,15,'Creuse'),(24,3,'Dordogne'),(25,11,'Doubs'),(26,23,'Drome'),(27,12,'Eure'),(28,8,'Eure et Loir'),(29,7,'Finistère'),(30,14,'Gard'),(31,17,'Haute garonne'),(32,17,'Gers'),(33,3,'Gironde'),(34,14,'Hérault'),(35,7,'Ile et Vilaine'),(36,8,'Indre'),(37,8,'Indre et Loire'),(38,23,'Isère'),(39,11,'Jura'),(40,3,'Landes'),(41,8,'Loir et Cher'),(42,23,'Loire'),(43,4,'Haute loire'),(44,20,'Loire Atlantique'),(45,8,'Loiret'),(46,17,'Lot'),(47,3,'Lot et Garonne'),(48,14,'Lozère'),(49,20,'Maine et Loire'),(50,5,'Manche'),(51,9,'Marne'),(52,9,'Haute Marne'),(53,20,'Mayenne'),(54,16,'Meurthe et Moselle'),(55,16,'Meuse'),(56,7,'Morbihan'),(57,16,'Moselle'),(58,6,'Nièvre'),(59,18,'Nord'),(60,21,'Oise'),(61,5,'Orne'),(62,18,'Pas de Calais'),(63,4,'Puy de Dôme'),(64,3,'Pyrénées Atlantiques'),(65,17,'Hautes Pyrénées'),(66,14,'Pyrénées Orientales'),(67,2,'Bas Rhin'),(68,2,'Haut Rhin'),(69,23,'Rhône'),(70,11,'Haute Saône'),(71,6,'Saône et Loire'),(72,20,'Sarthe'),(73,23,'Savoie'),(74,23,'Haute Savoie'),(75,13,'Paris'),(76,12,'Seine Maritime'),(77,13,'Seine et Marne'),(78,13,'Yvelines'),(79,22,'Deux Sèvres'),(80,21,'Somme'),(81,17,'Tarn'),(82,17,'Tarn et Garonne'),(83,19,'Var'),(84,19,'Vaucluse'),(85,20,'Vendée'),(86,22,'Vienne'),(87,15,'Haute Vienne'),(88,16,'Vosge'),(89,6,'Yonne'),(90,11,'Territoire de Belfort'),(91,13,'Essonne'),(92,13,'Haut de seine'),(93,13,'Seine Saint Denis'),(94,13,'Val de Marne'),(95,13,'Val d\'Oise'),(101,10,'Corse du Sud'),(102,10,'Haute Corse');
/*!40000 ALTER TABLE `department` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `feature`
--

DROP TABLE IF EXISTS `feature`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `feature` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `top_list_expire` datetime DEFAULT NULL,
  `partner_expire` datetime DEFAULT NULL,
  `pro_expire` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_1FD775667597D3FE` (`member_id`),
  CONSTRAINT `FK_1FD775667597D3FE` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `feature`
--

LOCK TABLES `feature` WRITE;
/*!40000 ALTER TABLE `feature` DISABLE KEYS */;
INSERT INTO `feature` (`id`, `member_id`, `top_list_expire`, `partner_expire`, `pro_expire`) VALUES (1,5,NULL,NULL,'2013-04-30 00:00:00'),(2,7,NULL,NULL,'2013-05-31 00:00:00'),(3,8,NULL,NULL,'2013-04-30 00:00:00'),(4,9,NULL,NULL,'2013-04-30 00:00:00'),(5,10,NULL,NULL,'2013-04-30 00:00:00'),(6,11,'2013-04-30 00:00:00',NULL,'2013-04-30 00:00:00'),(7,12,NULL,NULL,'2013-04-30 00:00:00'),(8,13,NULL,NULL,'2013-04-30 00:00:00'),(9,14,'2013-04-24 00:00:00',NULL,'2013-04-30 00:00:00'),(10,15,NULL,NULL,'2013-04-30 00:00:00'),(11,16,NULL,NULL,'2013-04-30 00:00:00'),(12,17,NULL,NULL,'2013-04-30 00:00:00'),(13,18,'2013-04-19 00:00:00','2013-04-25 00:00:00','2013-04-30 00:00:00'),(14,19,NULL,NULL,'2013-04-30 00:00:00'),(15,20,NULL,NULL,'2013-04-30 00:00:00'),(16,23,NULL,NULL,'2017-04-30 00:00:00'),(17,27,NULL,NULL,NULL),(18,28,NULL,NULL,NULL),(19,29,NULL,NULL,NULL),(20,34,NULL,NULL,NULL),(21,36,NULL,NULL,NULL);
/*!40000 ALTER TABLE `feature` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job`
--

DROP TABLE IF EXISTS `job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `category_id` int(11) DEFAULT NULL,
  `is_validate` tinyint(1) NOT NULL,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_FBD8E0F812469DE2` (`category_id`),
  CONSTRAINT `FK_FBD8E0F812469DE2` FOREIGN KEY (`category_id`) REFERENCES `job_category` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=40 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job`
--

LOCK TABLES `job` WRITE;
/*!40000 ALTER TABLE `job` DISABLE KEYS */;
INSERT INTO `job` (`id`, `category_id`, `is_validate`, `name`) VALUES (1,1,1,'Plomberie'),(2,1,1,'Electricité'),(3,1,1,'Menuiserie'),(4,1,1,'Serrurerie'),(5,1,1,'Papier peint'),(6,1,1,'Peinture intérieure'),(7,1,1,'Peinture extérieure'),(8,1,1,'Carrelage'),(9,1,1,'Parquet'),(10,1,1,'Sol (moquette et lino)'),(11,2,1,'Gros oeuvre'),(12,2,1,'Charpente'),(13,2,1,'Véranda'),(14,2,1,'Cuisine'),(15,2,1,'Salle de Bain'),(16,2,1,'Pose portes'),(17,2,1,'Pose fenêtres'),(18,2,1,'Pose stores'),(19,2,1,'Pose store électriques'),(20,3,1,'Chauffage fuel'),(21,3,1,'Chauffage gaz'),(22,3,1,'Chauffage solaire'),(23,3,1,'Chauffage bois'),(24,3,1,'Chauffage électrique'),(25,3,1,'Climatisation'),(26,3,1,'Pompe à chaleur'),(27,3,1,'Isolation murs'),(28,3,1,'Isolation sols'),(29,3,1,'Isolation exterieure'),(30,3,1,'Radiateurs'),(31,4,1,'Ravalement de façade'),(32,4,1,'Terrasse'),(33,4,1,'Terrasse bois'),(34,4,1,'Clôture'),(35,4,1,'Portail'),(36,4,1,'Portail électrique'),(37,4,1,'Piscine'),(38,5,1,'Architecte'),(39,5,1,'Architecte d\'intérieur');
/*!40000 ALTER TABLE `job` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `job_category`
--

DROP TABLE IF EXISTS `job_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `job_category` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_category`
--

LOCK TABLES `job_category` WRITE;
/*!40000 ALTER TABLE `job_category` DISABLE KEYS */;
INSERT INTO `job_category` (`id`, `name`) VALUES (1,'Populaires'),(2,'Gros chantiers'),(3,'Chauffage, isolation, clim'),(4,'Extérieur'),(5,'Design conseil');
/*!40000 ALTER TABLE `job_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member`
--

DROP TABLE IF EXISTS `member`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `member` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `department_id` int(11) DEFAULT NULL,
  `sponsor_id` int(11) DEFAULT NULL,
  `facebook_id` bigint(20) DEFAULT NULL,
  `lastname` varchar(255) NOT NULL,
  `firstname` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `salt` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `fax` varchar(255) DEFAULT NULL,
  `siret` varchar(255) DEFAULT NULL,
  `company_name` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL,
  `role` varchar(255) DEFAULT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_70E4FA78E7927C74` (`email`),
  UNIQUE KEY `UNIQ_70E4FA7812F7FB51` (`sponsor_id`),
  KEY `IDX_70E4FA78AE80F5DF` (`department_id`),
  CONSTRAINT `FK_70E4FA7812F7FB51` FOREIGN KEY (`sponsor_id`) REFERENCES `member` (`id`),
  CONSTRAINT `FK_70E4FA78AE80F5DF` FOREIGN KEY (`department_id`) REFERENCES `department` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=38 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member`
--

LOCK TABLES `member` WRITE;
/*!40000 ALTER TABLE `member` DISABLE KEYS */;
INSERT INTO `member` (`id`, `department_id`, `sponsor_id`, `facebook_id`, `lastname`, `firstname`, `email`, `password`, `salt`, `phone`, `fax`, `siret`, `company_name`, `is_active`, `role`, `created_at`, `updated_at`) VALUES (4,NULL,NULL,NULL,'barrault','vincent','vincent.barrault@supinfo.com','d5828f09e332e888c4c750e6431e70b4','778da9531b8446f4693833055fd02122','0123456789','0123456789',NULL,NULL,1,'user','2013-04-12 21:32:26','2013-04-17 04:21:13'),(5,45,NULL,NULL,'artisant3','artisant3','artisant3@fortutech.fr','4823b3bce960026293e13d431e0fc341','1f265b244372c14fb9f0777c058d866f','0123456789','0123456789','0123456789','Fretbay',1,'pro','2013-04-13 12:10:18','2013-04-13 12:10:18'),(7,45,NULL,NULL,'artisant2','artisant20','artisant2@fortutech.fr','4823b3bce960026293e13d431e0fc341','1f265b244372c14fb9f0777c058d866f','0123456789','0123456789','0123456789','Fretbay',1,'pro','2013-04-13 12:10:18','2013-05-10 18:03:36'),(8,45,NULL,NULL,'artisant1','artisant1','artisant1@fortutech.fr','4823b3bce960026293e13d431e0fc341','1f265b244372c14fb9f0777c058d866f','0123456789','0123456789','0123456789','Fretbay',1,'pro','2013-04-13 12:10:18','2013-04-13 12:10:18'),(9,45,NULL,NULL,'artisant4','artisant4','artisant4@fortutech.fr','4823b3bce960026293e13d431e0fc341','1f265b244372c14fb9f0777c058d866f','0123456789','0123456789','0123456789','Fretbay',1,'pro','2013-04-13 12:10:18','2013-04-13 12:10:18'),(10,45,NULL,NULL,'artisant5','artisant5','artisant5@fortutech.fr','4823b3bce960026293e13d431e0fc341','1f265b244372c14fb9f0777c058d866f','0123456789','0123456789','0123456789','Fretbay',1,'pro','2013-04-13 12:10:18','2013-04-13 12:10:18'),(11,45,NULL,NULL,'artisant6','artisant6','artisant6@fortutech.fr','4823b3bce960026293e13d431e0fc341','1f265b244372c14fb9f0777c058d866f','0123456789','0123456789','0123456789','Fretbay',1,'pro','2013-04-13 12:10:18','2013-04-13 12:10:18'),(12,45,NULL,NULL,'artisant7','artisant7','artisant7@fortutech.fr','4823b3bce960026293e13d431e0fc341','1f265b244372c14fb9f0777c058d866f','0123456789','0123456789','0123456789','Fretbay',1,'pro','2013-04-13 12:10:18','2013-04-13 12:10:18'),(13,45,NULL,NULL,'artisant8','artisant8','artisant8@fortutech.fr','4823b3bce960026293e13d431e0fc341','1f265b244372c14fb9f0777c058d866f','0123456789','0123456789','0123456789','Fretbay',1,'pro','2013-04-13 12:10:18','2013-04-13 12:10:18'),(14,8,NULL,NULL,'artisant9','artisant9','artisant9@fortutech.fr','4823b3bce960026293e13d431e0fc341','1f265b244372c14fb9f0777c058d866f','0123456789','0123456789','0123456789','Fretbay',1,'pro','2013-04-13 12:10:18','2013-04-13 12:10:18'),(15,45,NULL,NULL,'artisant10','artisant10','artisant10@fortutech.fr','4823b3bce960026293e13d431e0fc341','1f265b244372c14fb9f0777c058d866f','0123456789','0123456789','0123456789','Fretbay',1,'pro','2013-04-13 12:10:18','2013-04-13 12:10:18'),(16,45,NULL,NULL,'artisant11','artisant11','artisant11@fortutech.fr','4823b3bce960026293e13d431e0fc341','1f265b244372c14fb9f0777c058d866f','0123456789','0123456789','0123456789','Fretbay',1,'pro','2013-04-13 12:10:18','2013-04-13 12:10:18'),(17,45,NULL,NULL,'artisant12','artisant12','artisant12@fortutech.fr','4823b3bce960026293e13d431e0fc341','1f265b244372c14fb9f0777c058d866f','0123456789','0123456789','0123456789','Fretbay',1,'pro','2013-04-13 12:10:18','2013-04-13 12:10:18'),(18,45,NULL,NULL,'artisant13','artisant13','artisant13@fortutech.fr','4823b3bce960026293e13d431e0fc341','1f265b244372c14fb9f0777c058d866f','0123456789','0123456789','0123456789','Fretbay',1,'pro','2013-04-13 12:10:18','2013-04-13 12:10:18'),(19,45,NULL,NULL,'artisant14','artisant14','artisant14@fortutech.fr','4823b3bce960026293e13d431e0fc341','1f265b244372c14fb9f0777c058d866f','0123456789','0123456789','0123456789','Fretbay',1,'pro','2013-04-13 12:10:18','2013-04-13 12:10:18'),(20,45,NULL,NULL,'artisant15','artisant15','artisant15@fortutech.fr','4823b3bce960026293e13d431e0fc341','1f265b244372c14fb9f0777c058d866f','0123456789','0123456789','0123456789','Fretbay',1,'pro','2013-04-13 12:10:18','2013-04-13 12:10:18'),(21,NULL,NULL,NULL,'test3','test2','test@test.fr','786d21ba9cbed84eb5b648e53bff7e21','683d7ba3dc76dc3e3bd07ad0695b071e','0123456789','',NULL,NULL,1,'user','2013-04-14 02:43:42','2013-04-15 22:18:03'),(22,8,NULL,NULL,'test3','test2','admin@aze.fr','786d21ba9cbed84eb5b648e53bff7e21','683d7ba3dc76dc3e3bd07ad0695b071e','0123456789','',NULL,NULL,1,'admin','2013-04-14 02:43:42','2013-04-15 22:18:03'),(23,75,NULL,1381684898,'Bench','Mounir','benchnir@gmail.com','3a96750b9119883d7423741027ae7297','042e70b02b4122840854a87a9483dca7','0665175499','','','Bench',1,'pro','2013-04-24 14:02:52','2013-05-03 14:56:13'),(24,NULL,NULL,NULL,'Ben','Mou','mounir.bench@free.fr','0821b5ea43a6d5f54beef793278969dd','b7da098661bd098b28f370835e991d03','0665175499','',NULL,NULL,1,'admin','2013-04-25 19:58:25','2013-05-08 14:11:36'),(26,NULL,NULL,NULL,'fra','max','lordinaire@gmail.com','dae11cf8dd5cce401d23ece4c1c9aa93','6aa591da39f3cf3ceb57d3a31275bbd4','','',NULL,NULL,1,'user','2013-05-01 01:34:55','2013-05-01 01:36:19'),(27,1,NULL,NULL,'fra','maxou','maxime.frappat@gmail.com','a2700384d8f3b0bdef4fcaa397d7e247','9744d216a504b550d0f4f8d8d73c933d','','','2740288','lordcorp',1,'pro','2013-05-01 02:01:37','2013-05-01 02:09:52'),(28,1,NULL,NULL,'test','test','test@test.com','92058825ce32209db3dcd98ba72c7473','3676f45d317e6ad4cb9c0a62f3b4f4df','','','','',0,'pro','2013-05-01 17:33:58','2013-05-01 17:33:58'),(29,1,NULL,NULL,'test','test','e2583330@rmqkr.net','784a33eb2f73a38abbb4e531c04a2c07','e05f885cf77539542354d0b0ba9a0811','','','','',0,'pro','2013-05-01 17:35:38','2013-05-01 17:35:38'),(30,NULL,NULL,100001561683528,'Bee','Vincent','vincentb45@hotmail.fr','','4eb3d499a95860f5b79913982e29cc82','',NULL,NULL,NULL,1,'admin','2013-05-01 19:41:11','2013-05-01 19:41:28'),(31,NULL,NULL,760360146,'Javed','Usman','usmanjaved84@hotmail.com','','e0ff338056aa0b22a606146d5f07c7e2',NULL,NULL,NULL,NULL,1,'user','2013-05-06 10:10:44','2013-05-06 10:10:44'),(33,NULL,NULL,1321167632,'Souad','Elaini','sousoumadrid@hotmail.com','','356fc5fb41ebf8c93fdceadd398a2226','0675287690',NULL,NULL,NULL,1,'user','2013-05-08 22:16:44','2013-05-08 22:26:40'),(34,94,NULL,NULL,'Baccouche','Sami','samibaccouche@ymail.com','634f64bd4e3fe01f3e04d39bb6729069','add40bd90a9941ca4c55f5b3b2e8fd4b','0654565456','','','Sami Baxcouche',0,'pro','2013-05-21 21:22:55','2013-05-21 21:22:55'),(35,NULL,NULL,NULL,'Javed','Usman','uja@fretbay.com','5d1b52eb3e95770653d4e463034f08ba','ad1a2f56f78e886cd13ed15687e5431c','','',NULL,NULL,1,'user','2013-05-24 16:31:54','2013-05-24 16:39:01'),(36,91,NULL,NULL,'Usmannn','Javeddd','contact@fortutech.com','d6f9b82c0e0c0dc5157de86e88602166','43e51c8ed4eeb16d6ce7317afff10de3','','','','',1,'pro','2013-05-24 18:12:25','2013-05-24 18:12:56'),(37,NULL,NULL,100001141238065,'Javed','Usman','usman.javed@supinfo.com','','71ca9805765a47d5bf25ce90d7d1a531',NULL,NULL,NULL,NULL,1,'user','2013-05-24 18:17:22','2013-05-24 18:17:22');
/*!40000 ALTER TABLE `member` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `offer`
--

DROP TABLE IF EXISTS `offer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `offer` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `annonce_id` int(11) DEFAULT NULL,
  `price` int(11) NOT NULL,
  `description` varchar(1000) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_29D6873E7597D3FE` (`member_id`),
  KEY `IDX_29D6873E8805AB2F` (`annonce_id`),
  CONSTRAINT `FK_29D6873E7597D3FE` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`),
  CONSTRAINT `FK_29D6873E8805AB2F` FOREIGN KEY (`annonce_id`) REFERENCES `announcement` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `offer`
--

LOCK TABLES `offer` WRITE;
/*!40000 ALTER TABLE `offer` DISABLE KEYS */;
/*!40000 ALTER TABLE `offer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `picture`
--

DROP TABLE IF EXISTS `picture`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `picture` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `annonce_id` int(11) DEFAULT NULL,
  `path` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_16DB4F898805AB2F` (`annonce_id`),
  CONSTRAINT `FK_16DB4F898805AB2F` FOREIGN KEY (`annonce_id`) REFERENCES `announcement` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `picture`
--

LOCK TABLES `picture` WRITE;
/*!40000 ALTER TABLE `picture` DISABLE KEYS */;
INSERT INTO `picture` (`id`, `annonce_id`, `path`) VALUES (8,18,'f0eb6aa2aaedc5d38d0186458f8ec218nodejs.png'),(9,18,'81188ca2b1c8f38597b39571ef1b4593symfony.png'),(10,18,'60a4afed25c29e874b1ee503f79b35ddpureroi_home.png'),(11,18,'511bf1660598907e6f05f559556ac717IMG_20130110_122711.jpg'),(12,18,'1c7ab6bab4ff2f09126aabcb5b64d0bcIMG_20130110_122600.jpg'),(13,18,'0c7c2c8a9817385373aaa7d90dca2882symfony2.jpg'),(14,24,'2a8a2223f3061ce66ac5badfcb3d027epub_travaux.jpg'),(15,24,'7749f0d0e569766da32b2629323862a2Capture d’écran 2013-05-02 à 09.59.29.png'),(16,25,'18c0abef43cf4e866280d6348615f480Capture d’écran 2013-05-04 à 01.15.34.png'),(17,25,'1c17a770465e3a9dea462f0e58f0d8daCapture d’écran 2013-04-30 à 21.59.27.png'),(18,25,'161cc0f02784b7ddc85cc8eb5ebd8b08Capture d’écran 2013-05-02 à 09.59.29.png'),(19,26,'76608908f221d570519f3576c7e67e5aho-mezzeh.jpg'),(20,26,'7e48767eef8f4fb5567298d291f9e69ddessert-mouhallabieh.jpg'),(21,26,'ce081b47e91e32a5a69205750347cb66diapo3.jpg');
/*!40000 ALTER TABLE `picture` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `region`
--

DROP TABLE IF EXISTS `region`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `region` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=24 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `region`
--

LOCK TABLES `region` WRITE;
/*!40000 ALTER TABLE `region` DISABLE KEYS */;
INSERT INTO `region` (`id`, `name`) VALUES (1,'Toute la france'),(2,'Alsace'),(3,'Aquitaine'),(4,'Auvergne'),(5,'Basse Normandie'),(6,'Bourgogne'),(7,'Bretagne'),(8,'Centre'),(9,'Champagne Ardenne'),(10,'Corse'),(11,'Franche Comte'),(12,'Haute Normandie'),(13,'Ile de France'),(14,'Languedoc Roussillon'),(15,'Limousin'),(16,'Lorraine'),(17,'Midi-Pyrénées'),(18,'Nord Pas de Calais'),(19,'P.A.C.A'),(20,'Pays de la Loire'),(21,'Picardie'),(22,'Poitou Charente'),(23,'Rhone Alpes');
/*!40000 ALTER TABLE `region` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `report`
--

DROP TABLE IF EXISTS `report`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `member_id` int(11) DEFAULT NULL,
  `service_id` int(11) DEFAULT NULL,
  `reason` longtext NOT NULL,
  `complement` longtext NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_C42F77847597D3FE` (`member_id`),
  KEY `IDX_C42F7784ED5CA9E6` (`service_id`),
  CONSTRAINT `FK_C42F77847597D3FE` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`),
  CONSTRAINT `FK_C42F7784ED5CA9E6` FOREIGN KEY (`service_id`) REFERENCES `service` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `report`
--

LOCK TABLES `report` WRITE;
/*!40000 ALTER TABLE `report` DISABLE KEYS */;
INSERT INTO `report` (`id`, `member_id`, `service_id`, `reason`, `complement`, `created_at`, `updated_at`) VALUES (1,8,6,'test','azerty','2013-04-29 01:21:24','2013-04-29 01:21:24'),(2,8,6,'test','test','2013-04-29 01:25:43','2013-04-29 01:25:43'),(3,8,6,'test','test','2013-04-29 01:29:08','2013-04-29 01:29:08'),(4,8,6,'az','eaea','2013-04-29 01:29:41','2013-04-29 01:29:41'),(5,23,3,'je ne sais pas','pluskjzcbkzejbkcjjb celxjnkenczb','2013-04-30 22:53:32','2013-04-30 22:53:32');
/*!40000 ALTER TABLE `report` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service`
--

DROP TABLE IF EXISTS `service`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `main_job` int(11) DEFAULT NULL,
  `member_id` int(11) DEFAULT NULL,
  `department_id` int(11) DEFAULT NULL,
  `description` varchar(1000) DEFAULT NULL,
  `experience` int(11) DEFAULT NULL,
  `is_visible` tinyint(1) NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `UNIQ_E19D9AD27597D3FE` (`member_id`),
  KEY `IDX_E19D9AD29D039CF2` (`main_job`),
  KEY `IDX_E19D9AD2AE80F5DF` (`department_id`),
  CONSTRAINT `FK_E19D9AD27597D3FE` FOREIGN KEY (`member_id`) REFERENCES `member` (`id`),
  CONSTRAINT `FK_E19D9AD29D039CF2` FOREIGN KEY (`main_job`) REFERENCES `service_job` (`id`),
  CONSTRAINT `FK_E19D9AD2AE80F5DF` FOREIGN KEY (`department_id`) REFERENCES `department` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service`
--

LOCK TABLES `service` WRITE;
/*!40000 ALTER TABLE `service` DISABLE KEYS */;
INSERT INTO `service` (`id`, `main_job`, `member_id`, `department_id`, `description`, `experience`, `is_visible`, `updated_at`) VALUES (1,NULL,5,NULL,'',NULL,1,'2013-04-13 12:10:18'),(2,29,7,NULL,'je suis trop fort...',20,1,'2013-05-17 00:04:34'),(3,22,8,NULL,'',0,1,'2013-04-29 01:52:47'),(4,4,9,NULL,'speak about me',4,1,'2013-04-13 12:24:06'),(5,5,10,NULL,'hahaha',2,1,'2013-04-13 12:25:47'),(6,6,11,NULL,'jeune',1,1,'2013-04-13 12:26:36'),(7,7,12,NULL,'blablabla',10,1,'2013-04-13 12:28:06'),(8,8,13,NULL,'best',20,1,'2013-04-13 12:29:15'),(9,10,14,NULL,'parlons de moi...\r\n',18,1,'2013-04-13 12:30:22'),(10,11,15,NULL,'new',2,1,'2013-04-13 12:31:11'),(11,12,16,NULL,'picaso',40,1,'2013-04-13 12:32:51'),(12,13,17,NULL,'pzapazoj',9,1,'2013-04-13 12:34:00'),(13,16,18,NULL,'the one',20,1,'2013-04-14 01:47:14'),(14,17,19,NULL,'mec qui a rien compris',1,1,'2013-04-13 12:36:31'),(15,18,20,NULL,'blabla...',2,1,'2013-04-13 12:37:24'),(16,35,23,NULL,'eécgzoa\r\ncEHLIUGM',2,1,'2013-05-24 17:33:12'),(17,NULL,27,NULL,'',NULL,1,'2013-05-01 02:01:37'),(18,NULL,28,NULL,'',NULL,1,'2013-05-01 17:33:58'),(19,NULL,29,NULL,'',NULL,1,'2013-05-01 17:35:38'),(20,NULL,34,NULL,'',NULL,1,'2013-05-21 21:22:55'),(21,NULL,36,NULL,'',NULL,1,'2013-05-24 18:12:25');
/*!40000 ALTER TABLE `service` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `service_job`
--

DROP TABLE IF EXISTS `service_job`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `service_job` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `job_id` int(11) DEFAULT NULL,
  `service_id` int(11) DEFAULT NULL,
  `evaluation` int(11) NOT NULL,
  `price1` int(11) NOT NULL,
  `price2` int(11) NOT NULL,
  `price3` int(11) NOT NULL,
  `created_at` datetime NOT NULL,
  `updated_at` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `IDX_D988938FBE04EA9` (`job_id`),
  KEY `IDX_D988938FED5CA9E6` (`service_id`),
  CONSTRAINT `FK_D988938FBE04EA9` FOREIGN KEY (`job_id`) REFERENCES `job` (`id`),
  CONSTRAINT `FK_D988938FED5CA9E6` FOREIGN KEY (`service_id`) REFERENCES `service` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_job`
--

LOCK TABLES `service_job` WRITE;
/*!40000 ALTER TABLE `service_job` DISABLE KEYS */;
INSERT INTO `service_job` (`id`, `job_id`, `service_id`, `evaluation`, `price1`, `price2`, `price3`, `created_at`, `updated_at`) VALUES (4,1,4,5,100,99,98,'2013-04-13 12:23:59','2013-04-13 12:24:03'),(5,1,5,3,11,9,8,'2013-04-13 12:25:31','2013-04-13 12:25:35'),(6,3,6,2,11,10,9,'2013-04-13 12:26:28','2013-04-13 12:26:28'),(7,2,7,2,20,15,12,'2013-04-13 12:27:28','2013-04-13 12:27:28'),(8,2,8,5,200,180,170,'2013-04-13 12:28:39','2013-04-13 12:28:39'),(9,3,9,4,20,19,18,'2013-04-13 12:29:41','2013-04-13 12:29:44'),(10,1,9,4,19,18,17,'2013-04-13 12:29:55','2013-04-13 12:29:55'),(11,3,10,3,15,12,5,'2013-04-13 12:31:04','2013-04-13 12:31:04'),(12,2,11,5,999,990,980,'2013-04-13 12:32:42','2013-04-13 12:32:42'),(13,2,12,4,30,15,12,'2013-04-13 12:33:49','2013-04-13 12:33:49'),(14,3,13,4,11,10,4,'2013-04-13 12:34:46','2013-04-15 03:18:16'),(15,2,13,4,11,10,9,'2013-04-13 12:35:00','2013-04-13 12:35:00'),(16,1,13,5,12,11,10,'2013-04-13 12:35:14','2013-04-13 12:35:14'),(17,3,14,1,50,40,30,'2013-04-13 12:36:20','2013-04-13 12:36:20'),(18,2,15,2,50,40,20,'2013-04-13 12:37:13','2013-04-13 12:37:13'),(22,38,3,4,25,20,14,'2013-04-29 01:52:47','2013-04-29 01:53:01'),(28,21,2,2,25,19,13,'2013-05-10 15:07:33','2013-05-10 23:15:18'),(29,3,2,5,24,18,10,'2013-05-10 17:32:59','2013-05-16 01:16:19'),(35,38,16,5,50,40,30,'2013-05-24 17:33:12','2013-05-24 17:33:20'),(36,8,16,3,20,15,10,'2013-05-25 17:52:26','2013-05-25 17:52:26');
/*!40000 ALTER TABLE `service_job` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-07-24 14:22:56
